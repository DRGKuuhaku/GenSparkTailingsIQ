import React from 'react';

const UsersPage = () => (
  <div>
    <h2>Users Page</h2>
    <p>This is a placeholder for the Users Page.</p>
  </div>
);

export default UsersPage;
