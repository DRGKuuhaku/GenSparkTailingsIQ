import React from 'react';
const CompliancePage = () => <div><h2>Compliance Page</h2></div>;
export default CompliancePage;
