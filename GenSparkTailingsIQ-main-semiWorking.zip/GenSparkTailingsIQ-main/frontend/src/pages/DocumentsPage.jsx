import React from 'react';
const DocumentsPage = () => <div><h2>Documents Page</h2></div>;
export default DocumentsPage;
