import React from 'react';
const MonitoringPage = () => <div><h2>Monitoring Page</h2></div>;
export default MonitoringPage;
